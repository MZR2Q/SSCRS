# SSCRS — Open-source source for the ten visual directions & their videos

This bundle is the **editable source** behind the ten proposed visual directions
for the Saudi Society of Colon & Rectal Surgery (SSCRS) website, the walkthrough
**videos** rendered from them, and the **options PDF** shown to the board.

It is self-contained and MIT-licensed (see `LICENSE`). Hand it to any Claude
session (or any developer): they can **edit a design, re-render its video, and
re-upload** — instructions below.

---

## 1. What's inside

```
.
├── README.md                 ← this file
├── LICENSE                   ← MIT
├── src/
│   ├── engine.js             ← shared walkthrough engine (synthetic cursor, scroll,
│   │                            reveals, counters, FAQ accordion, doc-select, ripples,
│   │                            page transitions, end card). Drives window.__frame(t).
│   ├── data.js               ← shared content (members, committees, docs, tiers, FAQ…)
│   ├── demo6.html            ← Direction 06 "Seal of light" (particle seal, dark;
│   │                            white mode via ?mode=light). Bespoke, uses its own JS.
│   ├── tour15.html           ← Directions 01–05 in ONE file; pick theme with ?t=A..E
│   │                            (A=Clinical White, B=Navy Editorial, C=Paper & Palm,
│   │                             D=Institutional Grid, E=Monochrome Seal)
│   ├── tour7.html            ← Direction 07 Brutalist Editorial
│   ├── tour8.html            ← Direction 08 Horizontal Filmstrip
│   ├── tour9.html            ← Direction 09 Split-Screen
│   ├── tour10.html           ← Direction 10 Arabic-first Kufi (RTL)
│   ├── gen15.py              ← generator that writes tour15.html (edit here for 01–05)
│   ├── record.js             ← frame recorder: Playwright → JPEG frames
│   └── assets/               ← seal.png + board portraits (bm-01..04.jpg)
├── options/
│   ├── options.html          ← the board "options" deck (11 A4 pages), editable
│   ├── build_pdf.js          ← renders options.html → SSCRS-Style-Options.pdf
│   └── render/               ← the screenshots options.html references
├── SSCRS-Style-Options.pdf   ← the silent board deck (current screenshots)
└── SSCRS-Visual-Directions.pdf ← the detailed board presentation
```

> The 11 rendered **.mp4 videos are NOT in this bundle** (they are large). They
> live in the project repo under `videos/`. Anyone with this `src/` can
> regenerate any of them with the commands below.

---

## 2. How the videos are made (important)

The videos are **not screen recordings.** Each page exposes a single function
`window.__frame(t)` that positions *everything* (scroll, cursor, reveals,
counters, which FAQ question is open, which document is selected, transitions)
as a pure function of a time value `t` in seconds. `record.js` calls it for
every frame and saves a JPEG; `ffmpeg` assembles them at 60 fps. Deterministic,
no dropped frames.

Requirements: `node` + `playwright` (with Chromium) + `ffmpeg`.
```bash
npm i playwright && npx playwright install chromium   # once
```

---

## 3. Edit a design, then re-render its video

1. **Edit the source** for the direction you want:
   - Directions 01–05 → edit `src/gen15.py` then run `python3 src/gen15.py`
     (it rewrites `src/tour15.html`). Colors/fonts/radii per theme live in the
     `THEME` dict near the top.
   - Direction 06 → edit `src/demo6.html` directly.
   - Directions 07–10 → edit `src/tour7.html … tour10.html` directly.
   - Shared text (names, FAQ, documents…) → `src/data.js`.
   - Motion/timeline (cursor path, scroll stops, FAQ open times, clicks) →
     the `CFG` object near the bottom of each tour file, or the timeline
     constants inside `demo6.html`.

2. **Preview a still** (fast check) — render one frame at time t:
   ```bash
   cd src
   node -e "const{chromium}=require('playwright');(async()=>{const b=await chromium.launch({args:['--allow-file-access-from-files']});const p=await (await b.newContext({viewport:{width:1440,height:900}})).newPage();await p.goto('file://'+require('path').resolve('tour15.html')+'?t=A',{waitUntil:'networkidle'});await p.evaluate(()=>document.fonts.ready);for(let i=0;i<40;i++){if(await p.evaluate(()=>window.__frame(0)))break;await p.waitForTimeout(80)}await p.evaluate(()=>window.__frame(20));await p.screenshot({path:'preview.png'});await b.close()})()"
   ```

3. **Render the full video** (frames → mp4). `record.js` args: `<page> <outdir> <fps> <seconds>`.
   ```bash
   cd src
   mkdir -p frames
   node record.js "tour15.html?t=A" frames 60 59          # dir 01
   # or: node record.js "demo6.html" frames 60 61          # dir 06 dark
   # or: node record.js "demo6.html?mode=light" frames 60 61  # dir 06 white
   # or: node record.js "tour7.html" frames 60 45           # dir 07
   ffmpeg -y -framerate 60 -i frames/f%05d.jpg -c:v libx264 -preset slower -crf 15 -pix_fmt yuv420p -movflags +faststart -an ../my-video.mp4
   ```
   Durations used originally: tour15 = 59 s, demo6 = 61 s, tour7 = 45 s,
   tour8 = 47 s, tour9 = 41 s, tour10 = 41 s.

4. **Re-upload / commit** to the repo (branch `ccr-0d64da71-ozdd7x`, or whatever
   branch you are told to use):
   ```bash
   cp my-video.mp4 videos/SSCRS-Direction-01-Clinical-White.mp4
   git add videos/ && git commit -m "Update direction-01 video" && git push
   ```

---

## 4. Rebuild the options PDF (with fresh screenshots)

```bash
cd src && node capture_opt.js      # (included) re-captures options/render/*.jpg from the pages
cd ../options && node build_pdf.js # writes SSCRS-Style-Options.pdf
```
`capture_opt.js` calls `__frame(t)` on each page at chosen moments, hides the
cursor, and screenshots — so the deck always matches the live designs.

---

## 5. The ten directions (quick key)

| # | Name | One line |
|---|---|---|
| 01 | Clinical White | one navy on pure white, Stripe/Linear calm |
| 02 | Navy Editorial | dark navy hero, large Times, medical-journal feel |
| 03 | Paper & Palm | palm green on warm paper |
| 04 | Institutional Grid | sharp bento tiles, Saudi-gov language |
| 05 | Monochrome Seal | one-colour seal, wide space, Apple logic |
| 06 | Seal of Light | seal drawn from ~68k light particles, immersive dark (+ white) |
| 07 | Brutalist Editorial | giant type, news ticker, B/W photos |
| 08 | Horizontal Filmstrip | sideways panel scroll |
| 09 | Split-Screen | fixed navy panel + flowing content |
| 10 | Arabic-first Kufi | RTL, Reem Kufi, Islamic pattern |

Every video includes real interactions: an **FAQ question opening on screen** and
a **document being selected** in the regulations library, plus hovers, counters
and page transitions.

---

*MIT-licensed. Generated 2026-11-14. Edit freely.*
