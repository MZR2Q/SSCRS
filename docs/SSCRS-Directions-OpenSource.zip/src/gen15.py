# -*- coding: utf-8 -*-
import os
OUT='/tmp/claude-0/-home-user-SSCRS/df70ff8e-71b4-561d-adcf-7222927e233a/scratchpad/proposals/tpl2/tour15.html'
M=[
 dict(n='Prof. Samar Alhomoud',r='Chairperson of the Board',t='Consultant Colorectal Surgeon · Professor of Surgery',i='King Faisal Specialist Hospital & Research Centre',img='assets/bm-01.jpg',
      bio='International expert in colorectal cancer screening and prevention who has helped draft national, regional and WHO policy.'),
 dict(n='Dr. Anmar Faisal Semilan',r='Board Member',t='Colorectal & General Surgery',i='King Fahad Armed Forces Hospital',img='assets/bm-02.jpg'),
 dict(n='Dr. Rami Alsairafi',r='Board Member',t='Colorectal & General Surgery',i='Security Forces Hospital · Riyadh',img='assets/bm-03.jpg'),
 dict(n='Prof. Ahmad Zubaidi',r='Board Member',t='Professor of Colorectal & General Surgery',i='King Khalid University Hospital · Riyadh',img='assets/bm-04.jpg'),
]
COMS=[('Executive Committee','Standing · formed by the Board','Delegated day-to-day authority between Board meetings.'),
 ('Internal Audit','Standing · independent members','Reviews internal controls, financial records and compliance.'),
 ('Nominations & Remuneration','Standing · independent members','Sets criteria for Board roles and the remuneration policy.'),
 ('Scientific & Education','Standing · formed by the Board','Programmes the Annual Forum, workshops and accredited courses.'),
 ('Awareness & Community','Standing · formed by the Board','Leads public campaigns on early detection and screening.'),
 ('Elections Committee','Temporary · General Assembly','Runs each Board election and announces its result.')]
DOCS=[('SSCRS Basic Bylaw','2025'),('Membership Regulations','2025'),('Financial Regulations','2024'),('Board Election Rules','2024'),('Membership Application Form','Form')]
TIERS=[('Affiliate','SAR 300','residents and trainees',['Educational activities','Member rate at the Forum','Newsletter']),
 ('Regular','SAR 600','consultants and specialists',['Everything in Affiliate','Voting rights','Board eligibility','Directory listing']),
 ('Honorary','By invitation','conferred by the Board',['Distinguished service','Lifetime membership','Honorary listing'])]
STATS=[('2009','Established',None),('500','Members','+'),('6','Committees',None),('8','Board',None),('15','Years','+')]
PILLARS=['Clinical Excellence','Education & Training','Research & Innovation','Community Awareness']
FAQ=[('How do I become a member?','Choose a category — affiliate, regular or honorary — and apply online or by form. The Board reviews applications monthly.'),
 ('What does membership include?','Access to educational activities, member rates at the Annual Forum, voting rights for regular members, and a listing in the members directory.'),
 ('When is the Annual Forum?','15–17 April 2026 in Riyadh — three days of keynote lectures, live surgery demonstrations and hands-on workshops.'),
 ('How are committees formed?','Under Chapter 5 of the Basic Bylaw, the Board and the General Assembly form standing and temporary committees of three to five members.')]

THEME={
'A':dict(accent='#1B4C93',accent2='#3C7A2A',bg='#FFFFFF',card='#FFFFFF',ink='#0B2444',body='#4B5565',mute='#7A869A',line='#E3E8EF',tint='#EEF3FA',tintsoft='#F7F9FC',plate='#0B2444',r='12px',rbtn='10px',rtag='6px',disp="'Times New Roman',Times,serif",ui='Inter,sans-serif',hero='A'),
'B':dict(accent='#0B2444',accent2='#4E9E37',bg='#F6F4EE',card='#FFFFFF',ink='#141A24',body='#4A5260',mute='#7C8494',line='#E4E0D6',tint='#EEEBE2',tintsoft='#F6F4EE',plate='#0B2444',r='6px',rbtn='6px',rtag='4px',disp="'Times New Roman',Times,serif",ui='Inter,sans-serif',hero='B'),
'C':dict(accent='#3C7A2A',accent2='#3C7A2A',bg='#F8F6F1',card='#FFFFFF',ink='#1E2A22',body='#55605A',mute='#8A948E',line='#E8E4DA',tint='#E7F1E2',tintsoft='#F3F6EE',plate='#2F5A24',r='16px',rbtn='14px',rtag='999px',disp="'Times New Roman',Times,serif",ui='Inter,sans-serif',hero='C'),
'D':dict(accent='#1B4C93',accent2='#1B4C93',bg='#FFFFFF',card='#FFFFFF',ink='#0B2444',body='#4B5565',mute='#7A869A',line='#D9E0EA',tint='#F3F5F8',tintsoft='#F7F9FB',plate='#0B2444',r='4px',rbtn='4px',rtag='3px',disp="'Times New Roman',Times,serif",ui="'IBM Plex Sans',sans-serif",hero='D'),
'E':dict(accent='#0B2444',accent2='#1E7F8A',bg='#FFFFFF',card='#FFFFFF',ink='#0B2444',body='#5B6B86',mute='#8A94A6',line='#E6EAF0',tint='#F7F8FA',tintsoft='#F7F8FA',plate='#0B2444',r='14px',rbtn='999px',rtag='999px',disp="'Times New Roman',Times,serif",ui='Inter,sans-serif',hero='E'),
}
def rootvars(t,T):
 return f'html[data-t="{t}"]{{--accent:{T["accent"]};--accent2:{T["accent2"]};--bg:{T["bg"]};--card:{T["card"]};--ink:{T["ink"]};--body:{T["body"]};--mute:{T["mute"]};--line:{T["line"]};--tint:{T["tint"]};--tintsoft:{T["tintsoft"]};--plate:{T["plate"]};--r:{T["r"]};--rbtn:{T["rbtn"]};--rtag:{T["rtag"]};--disp:{T["disp"]};--ui:{T["ui"]};--cur:{T["ink"]};--curr:#fff;--fade:{T["plate"]};--endfg:#fff}}'

# hero variants
def heroA():
 return '''<section class="hero hero-A" id="hero"><div class="wrap grid-hero">
  <div><div class="eyebrow rv" data-rv="1.2">Established 2009 · 1430H · Riyadh</div>
   <h1 class="rv" data-rv="1.5">Saudi Society of Colon &amp; Rectal Surgery</h1>
   <div class="subar rv ar" data-rv="1.9">الجمعية السعودية لجراحة القولون والمستقيم</div>
   <p class="lead rv" data-rv="2.2">The national home for colorectal surgical excellence — advancing education, research and public awareness across the Kingdom.</p>
   <div class="btns rv" data-rv="2.5"><a class="btn btn-p" id="cta">Become a member</a><a class="btn btn-o">About the society</a></div></div>
  <div class="card forumcard rv" data-rv="2.0"><div class="ey2">Annual Forum · 15–17 April 2026</div><h3>SSCRS Annual Forum 2026 — registration is open</h3><p>Three days of lectures, live surgery and hands-on workshops in Riyadh.</p><a class="link">Register →</a></div>
 </div></section>'''
def heroB():
 return '''<section class="hero hero-B" id="hero"><div class="wrap grid-heroB">
  <img class="seal rv" data-rv="1.2" src="assets/seal.png">
  <div><div class="kick rv" data-rv="1.5">THE NATIONAL SOCIETY · ESTABLISHED 2009 / 1430H</div>
   <h1 class="rv" data-rv="1.8">Advancing colorectal surgery in the Kingdom.</h1>
   <div class="rule rv" data-rv="2.2"></div>
   <div class="subar ar rv" data-rv="2.4">الجمعية السعودية لجراحة القولون والمستقيم</div>
   <p class="lead rv" data-rv="2.7">A professional home for surgeons, trainees and researchers — organising scientific work, strengthening fellowship, and raising public awareness.</p>
   <div class="btns rv" data-rv="3.0"><a class="btn btn-g" id="cta">Become a member</a><a class="btn btn-o2">Annual Forum 2026</a></div></div>
 </div></section>'''
def heroC():
 return '''<section class="hero hero-C" id="hero"><div class="wrap grid-heroC">
  <div class="plateC rv" data-rv="1.2"><img src="assets/seal.png"></div>
  <div><span class="eyebrow pill rv" data-rv="1.6">Established 2009 · 1430H</span>
   <h1 class="rv" data-rv="1.9">Caring for colorectal health across the Kingdom.</h1>
   <div class="subar ar rv" data-rv="2.3">الجمعية السعودية لجراحة القولون والمستقيم</div>
   <p class="lead rv" data-rv="2.6">Surgeons, trainees and researchers working together — through education, research and public awareness.</p>
   <div class="btns rv" data-rv="2.9"><a class="btn btn-p" id="cta">Become a member</a><a class="btn btn-o">About the society</a></div></div>
 </div></section>'''
def heroD():
 return '''<section class="hero hero-D" id="hero"><div class="wrap"><div class="bento">
  <div class="t t-main rv" data-rv="1.4"><span class="no">01 / Identity</span><h1>The national society for colorectal surgery.</h1><div class="subar ar">الجمعية السعودية لجراحة القولون والمستقيم</div><p>Established 2009 / 1430H under the Saudi Commission for Health Specialties.</p><div class="btns"><a class="btn btn-p" id="cta">Become a member</a><a class="btn btn-o">About</a></div></div>
  <div class="t t-seal rv" data-rv="1.7"><img src="assets/seal.png"><div><div class="k">ANNUAL FORUM · 15–17 APRIL 2026</div><h3>SSCRS Annual Forum 2026 — registration is open</h3><a class="link">Register →</a></div></div>
  <div class="t t-stat rv" data-rv="2.0"><div><b>2009</b><span>Established</span></div><div><b>500+</b><span>Members</span></div><div><b>6</b><span>Committees</span></div><div><b>8</b><span>Board</span></div></div>
  <div class="t t-q rv" data-rv="2.2"><span class="no">02</span><h4>Membership</h4><p>Affiliate, regular and honorary.</p></div>
  <div class="t t-q rv" data-rv="2.35"><span class="no">03</span><h4>Education</h4><p>CME, workshops and the fellowship.</p></div>
  <div class="t t-cta rv" data-rv="2.5"><h4>Awareness Month</h4><a class="link">Campaign →</a></div>
 </div></div></section>'''
def heroE():
 return '''<section class="hero hero-E" id="hero"><div class="wrap">
  <img class="seal mono rv" data-rv="1.2" src="assets/seal.png">
  <h1 class="rv" data-rv="1.7">Saudi Society of Colon &amp; Rectal Surgery</h1>
  <div class="subar ar rv" data-rv="2.1">الجمعية السعودية لجراحة القولون والمستقيم</div>
  <p class="lead rv" data-rv="2.4">The national home for colorectal surgical excellence. Established 2009 · 1430H.</p>
  <div class="btns rv" data-rv="2.7"><a class="btn btn-p" id="cta">Become a member</a><a class="link">About the society →</a></div>
 </div></section>'''

mems=''.join(f'<div class="card member rv" id="mem-{i}"><img src="{m["img"]}"><div class="b"><h4>{m["n"]}</h4><div class="rr">{m["t"]}</div><p class="meta">{m["i"]}</p></div></div>' for i,m in enumerate(M[1:]))
coms=''.join(f'<div class="card com rv" id="com-{i}"><div class="meta">{c[1]}</div><h4>{c[0]}</h4><p>{c[2]}</p><div class="chair">Chair · <b>To be announced</b></div></div>' for i,c in enumerate(COMS))
docs=''.join(f'<div class="doc" id="doc-{i}"><div>{d[0]}</div><span>{d[1]} · PDF</span></div>' for i,d in enumerate(DOCS))
tiers=''.join(f'<div class="card tier rv{" hl" if i==1 else ""}" id="tier-{i}"><h4>{t[0]}</h4><div class="price">{t[1]}</div><div class="per">{t[2]}</div><ul class="checks">{"".join(f"<li>{x}</li>" for x in t[3])}</ul><a class="btn {"btn-p" if i==1 else "btn-o"}">Apply</a></div>' for i,t in enumerate(TIERS))
statshtml=''.join(f'<div class="stat"><b class="cnt" data-v="{s[0]}"{(" data-s=\""+s[2]+"\"") if s[2] else ""}>0</b><span>{s[1]}</span></div>' for s in STATS)
pillars=''.join(f'<div class="pill rv">{p}</div>' for p in PILLARS)
events=''.join(f'<div class="ev rv" id="ev-{i}"><div class="date"><b>{d}</b><span>{mo}</span></div><div><h4>{ti}</h4><p class="meta">{su}</p></div><a class="btn btn-o sm">Register</a></div>' for i,(d,mo,ti,su) in enumerate([('22','JAN','Laparoscopic colorectal skills workshop','Hands-on · King Fahad Medical City, Riyadh · 8 CME hours'),('05','FEB','Webinar: colorectal cancer screening in practice','Online · 19:00–20:30 · 1.5 CME hours'),('01','MAR','Colorectal Cancer Awareness Month — campaign launch','Riyadh, Jeddah, Dammam · with the Ministry of Health')]))
faq=''.join(f'<div class="q" id="faq-q{i}"><div class="qh">{q}<span class="chev"></span></div><div class="qb"><p>{a}</p></div></div>' for i,(q,a) in enumerate(FAQ))
chair=f'''<div class="feature rv" id="chair"><img src="{M[0]["img"]}"><div class="fb"><span class="tag">{M[0]["r"]}</span><h2>{M[0]["n"]}</h2><div class="rr">{M[0]["t"]}</div><p>{M[0]["bio"]}</p><span class="tag">Founding member</span><span class="tag">Honorary Fellow, ASCRS</span></div></div>'''

CSS = r'''
*{box-sizing:border-box;margin:0;padding:0}img{display:block;max-width:100%}a{color:inherit;text-decoration:none}ul{list-style:none}
body{font-family:var(--ui);color:var(--body);background:var(--bg);font-size:16px;line-height:1.6}
.ar{font-family:"Noto Naskh Arabic",serif;direction:rtl}
.wrap{max-width:1180px;margin:0 auto;padding:0 44px}
h1,h2,h3,h4{color:var(--ink)}
header{position:fixed;top:0;left:0;right:0;height:72px;display:flex;align-items:center;z-index:30;background:color-mix(in srgb,var(--bg) 86%,transparent);border-bottom:1px solid var(--line);backdrop-filter:blur(8px)}
header .wrap{display:flex;align-items:center;gap:36px;width:100%}
.lock{display:flex;align-items:center;gap:11px;color:var(--ink);font-weight:600;font-size:14px;line-height:1.2}
.lock img{width:38px;height:38px}
nav{display:flex;gap:24px;font-size:14.5px;color:var(--body);margin-inline-start:auto}
.btn{display:inline-flex;align-items:center;justify-content:center;height:46px;padding:0 22px;border-radius:var(--rbtn);font-weight:600;font-size:14.5px;font-family:var(--ui)}
.btn.sm{height:40px;padding:0 16px;font-size:13.5px}
.btn-p{background:var(--accent);color:#fff}.btn-o{border:1px solid var(--line);color:var(--ink);background:var(--card)}
.btn-g{background:var(--accent2);color:#fff}.btn-o2{border:1px solid rgba(255,255,255,.4);color:#fff}
.link{color:var(--accent);font-weight:600;font-size:14.5px}
.hcta{background:var(--accent);color:#fff;height:42px;display:inline-flex;align-items:center;padding:0 18px;border-radius:var(--rbtn);font-weight:600;font-size:14px}
section{padding:84px 0}
.sechead{margin-bottom:34px}
.kk{display:inline-block;font-size:12.5px;font-weight:600;color:var(--accent2);letter-spacing:.02em;margin-bottom:12px}
h2.title{font-family:var(--disp);font-size:40px;font-weight:700;line-height:1.1;letter-spacing:-.01em}
.lead{font-size:17px;max-width:56ch;margin-bottom:0;color:var(--body)}
.grid-3{display:grid;grid-template-columns:repeat(3,1fr);gap:18px}
.grid-4{display:grid;grid-template-columns:repeat(4,1fr);gap:18px}
.card{background:var(--card);border:1px solid var(--line);border-radius:var(--r);padding:26px}
.card h4{font-size:17px;font-weight:600;margin-bottom:6px}.card p{font-size:14.5px}
.glance .card .ic{width:36px;height:36px;border-radius:calc(var(--r) - 4px);background:var(--tint);display:grid;place-items:center;margin-bottom:16px}
.glance .card .ic i{width:14px;height:14px;border:2px solid var(--accent);border-radius:3px;display:block}
.glance .card .link{display:inline-block;margin-top:12px}
.meta{font-size:13px;color:var(--mute)}
.tag{display:inline-block;font-size:12.5px;font-weight:600;color:var(--accent);background:var(--tint);padding:4px 11px;border-radius:var(--rtag);margin:0 6px 6px 0}
.plate{background:var(--plate);color:#fff;border-radius:var(--r);padding:44px}
.plate .kk{color:#9FD88B}.plate h2.title{color:#fff;margin-bottom:24px}
.stats{display:flex;justify-content:space-between;gap:12px}
.stat b{display:block;font-family:var(--disp);font-size:40px;font-weight:700;line-height:1;margin-bottom:6px;font-variant-numeric:tabular-nums}
.stat span{font-size:12.5px;opacity:.72;letter-spacing:.04em;text-transform:uppercase}
.feature{display:grid;grid-template-columns:320px 1fr;gap:0;background:var(--plate);color:#fff;border-radius:var(--r);overflow:hidden}
.feature img{width:100%;height:100%;object-fit:cover;object-position:top;aspect-ratio:4/5}
.feature .fb{padding:36px 40px}.feature h2{color:#fff;font-family:var(--disp);font-size:34px;margin:10px 0 4px}
.feature .rr{color:#9FD88B;font-weight:600;font-size:15px;margin-bottom:14px}.feature p{font-size:15px;opacity:.9;max-width:58ch;margin-bottom:16px}
.feature .tag{background:rgba(255,255,255,.12);color:#fff}
.members{display:grid;grid-template-columns:repeat(3,1fr);gap:18px;margin-top:18px}
.member{padding:0;overflow:hidden}.member img{aspect-ratio:4/3.4;object-fit:cover;object-position:top}.member .b{padding:20px 22px}
.member .rr{font-size:14px;color:var(--accent);font-weight:600;margin:4px 0 6px}
.tier{display:flex;flex-direction:column}.tier .price{font-family:var(--disp);font-size:34px;color:var(--ink);font-weight:700;margin:10px 0 2px}
.tier .per{font-size:13px;color:var(--mute);margin-bottom:16px}
.checks li{position:relative;padding-inline-start:22px;font-size:14.5px;margin-bottom:8px;color:var(--body)}
.checks li:before{content:"";position:absolute;left:0;top:7px;width:9px;height:5px;border-left:2px solid var(--accent2);border-bottom:2px solid var(--accent2);transform:rotate(-45deg)}
.tier .btn{margin-top:auto;align-self:flex-start}.tier.hl{box-shadow:0 0 0 2px var(--accent)}
.com .chair{margin-top:14px;padding-top:12px;border-top:1px solid var(--line);font-size:13.5px}.com .chair b{color:var(--ink)}
.docwrap{display:grid;grid-template-columns:1fr 1.25fr;gap:18px;align-items:start}
.doclist{padding:0;overflow:hidden}
.doc{display:flex;justify-content:space-between;align-items:center;padding:17px 22px;border-bottom:1px solid var(--line);font-size:15px}
.doc:last-child{border-bottom:0}.doc span{font-size:13px;color:var(--mute)}.doc b{color:var(--ink)}
.docview .dvh{display:flex;justify-content:space-between;align-items:center;padding:16px 22px;border-bottom:1px solid var(--line)}
.docview{padding:0}.docview h4{font-size:16px}.docview .dvbtn{font-size:12.5px;color:var(--accent);font-weight:600}
.docprev{height:290px;display:grid;place-items:center;color:var(--mute);font-size:12.5px;letter-spacing:.16em;text-transform:uppercase;background:var(--tintsoft)}
.band{display:grid;grid-template-columns:1fr auto;gap:30px;align-items:center;background:var(--plate);color:#fff;border-radius:var(--r);padding:40px 44px}
.band .kk{color:#9FD88B}.band h3{font-family:var(--disp);font-size:30px;color:#fff;margin:6px 0 10px}.band p{opacity:.85;font-size:15px}
.ev{display:grid;grid-template-columns:84px 1fr auto;gap:22px;align-items:center;padding:20px 0;border-bottom:1px solid var(--line)}
.ev:last-child{border-bottom:0}.date{text-align:center;border-radius:var(--r);background:var(--tint);padding:12px 0;color:var(--ink)}
.date b{display:block;font-family:var(--disp);font-size:26px;line-height:1}.date span{font-size:11px;color:var(--accent);font-weight:600}
.ev h4{font-size:17px;margin-bottom:3px}
.pillars{display:grid;grid-template-columns:repeat(4,1fr);gap:12px}
.pill{padding:16px 18px;border:1px solid var(--line);border-radius:var(--r);background:var(--tint);font-weight:600;color:var(--ink);font-size:14.5px}
.faq{max-width:900px;margin:0 auto;border:1px solid var(--line);border-radius:var(--r);background:var(--card);overflow:hidden}
.faq .q{border-top:1px solid var(--line)}.faq .q:first-child{border-top:0}
.faq .qh{display:flex;justify-content:space-between;align-items:center;gap:20px;padding:22px 24px;font-size:17.5px;color:var(--ink);font-weight:500}
.faq .qh .chev{position:relative;width:16px;height:16px;flex:none}
.faq .qh .chev:before,.faq .qh .chev:after{content:"";position:absolute;top:7px;width:10px;height:2px;background:var(--mute);border-radius:2px}
.faq .qh .chev:before{left:0;transform:rotate(45deg)}.faq .qh .chev:after{left:6px;transform:rotate(-45deg)}
.faq .qb{overflow:hidden;max-height:0;opacity:0}.faq .qb p{padding:0 24px 24px;color:var(--body);font-size:15px;max-width:74ch;line-height:1.7}
footer{background:var(--plate);color:rgba(255,255,255,.8);padding:50px 0 34px}
footer .cols{display:grid;grid-template-columns:1.5fr 1fr 1fr 1fr;gap:34px;margin-bottom:30px}
footer h5{color:#fff;font-size:14px;margin-bottom:12px}footer li{font-size:14px;margin-bottom:7px;opacity:.82}
footer .copy{border-top:1px solid rgba(255,255,255,.16);padding-top:18px;font-size:13px;opacity:.7;display:flex;justify-content:space-between}
/* reveal base */
.rv{opacity:0}
/* ---------- hero variants ---------- */
.hero{padding-top:150px;padding-bottom:90px}
.hero-A,.hero-B,.hero-C,.hero-D,.hero-E{display:none}
html[data-t="A"] .hero-A{display:block}html[data-t="B"] .hero-B{display:block}html[data-t="C"] .hero-C{display:block}html[data-t="D"] .hero-D{display:block}html[data-t="E"] .hero-E{display:block}
.eyebrow{font-size:13px;color:var(--mute);font-weight:500;margin-bottom:18px}
.subar{font-size:22px;color:var(--accent);margin:14px 0 18px}
h1{font-family:var(--disp);font-weight:700;letter-spacing:-.01em}
.grid-hero{display:grid;grid-template-columns:1.2fr .85fr;gap:60px;align-items:center}
.hero-A h1{font-size:54px;line-height:1.06;color:var(--ink)}
.forumcard{align-self:center}.forumcard .ey2{font-size:13px;color:var(--accent2);font-weight:600;margin-bottom:10px}.forumcard h3{font-family:var(--disp);font-size:25px;line-height:1.22;margin-bottom:10px}.forumcard p{font-size:14.5px;margin-bottom:16px}
.btns{display:flex;gap:12px}
/* B navy hero band on a cream page */
.hero-B{background:var(--plate);color:#fff}
.grid-heroB{display:grid;grid-template-columns:230px 1fr;gap:56px;align-items:center}
.hero-B .seal{width:230px;border-radius:50%;background:#fff;padding:9px}
.hero-B .kick{font-size:12px;letter-spacing:.06em;color:rgba(255,255,255,.6);margin-bottom:18px}
.hero-B h1{font-size:60px;line-height:1.04;color:#fff;max-width:15ch}
.hero-B .rule{width:54px;height:3px;background:var(--accent2);margin:22px 0 18px}
.hero-B .subar{color:rgba(255,255,255,.82)}.hero-B .lead{color:rgba(255,255,255,.7)}
/* C paper */
.grid-heroC{display:grid;grid-template-columns:300px 1fr;gap:64px;align-items:center}
.plateC{width:300px;height:300px;border-radius:50%;background:var(--tint);display:grid;place-items:center}.plateC img{width:220px}
.hero-C .pill{background:var(--tint);padding:6px 13px;border-radius:999px;color:var(--accent)}
.hero-C h1{font-size:52px;line-height:1.08;color:var(--ink)}
/* D bento */
.bento{display:grid;grid-template-columns:repeat(12,1fr);grid-auto-rows:120px;gap:14px}
.t{border:1px solid var(--line);border-radius:var(--r);padding:24px;position:relative;background:var(--card)}
.t .no{position:absolute;top:16px;inset-inline-end:18px;font-size:11px;color:var(--mute)}
.t-main{grid-column:span 7;grid-row:span 3;display:flex;flex-direction:column;justify-content:flex-end}
.t-main h1{font-size:40px;line-height:1.06;margin-bottom:10px;max-width:16ch}.t-main .subar{font-size:18px}.t-main p{font-size:14.5px;margin-bottom:18px;max-width:52ch}
.t-seal{grid-column:span 5;grid-row:span 2;background:var(--plate);color:#fff;display:flex;align-items:center;gap:22px;border:0}
.t-seal img{width:120px;height:120px;border-radius:50%;background:#fff;padding:5px;flex:none}
.t-seal .k{font-size:11px;color:rgba(255,255,255,.6);margin-bottom:8px}.t-seal h3{font-family:var(--disp);font-size:22px;line-height:1.2;margin-bottom:8px}.t-seal .link{color:#fff;border-bottom:1px solid var(--accent2)}
.t-stat{grid-column:span 5;grid-row:span 1;background:var(--tint);border:0;display:flex;align-items:center;justify-content:space-between}
.t-stat b{display:block;font-size:24px;color:var(--ink);font-weight:600;line-height:1}.t-stat span{font-size:11px;color:var(--mute)}
.t-q{grid-column:span 3;grid-row:span 1}.t-q h4{font-size:15px;margin-bottom:4px}.t-q p{font-size:13px}
.t-cta{grid-column:span 3;background:var(--accent2);border:0;color:#fff;display:flex;flex-direction:column;justify-content:space-between}.t-cta h4{color:#fff;font-size:16px}.t-cta .link{color:#fff}
/* E centered */
.hero-E{text-align:center}.hero-E .seal{width:230px;margin:0 auto 34px}
.hero-E.mono .seal,.hero-E .seal.mono{filter:grayscale(1) sepia(1) hue-rotate(188deg) saturate(2.2) brightness(.78)}
.hero-E h1{font-size:58px;line-height:1.05;color:var(--ink);max-width:18ch;margin:0 auto}
.hero-E .subar{margin-left:auto;margin-right:auto}.hero-E .lead{margin:0 auto 24px}.hero-E .btns{justify-content:center;align-items:center}
.hero-E .btn-p{border-radius:999px;height:50px;padding:0 26px}
/* light-mode param unused here (themes already light), keep hook */
'''

VIEWS = (heroA()+heroB()+heroC()+heroD()+heroE()+f'''
<section class="glance"><div class="wrap"><div class="grid-4">
 <div class="card rv" id="g0"><div class="ic"><i></i></div><h4>Annual Forum</h4><p>The Kingdom's premier colorectal surgery gathering.</p><a class="link">Details →</a></div>
 <div class="card rv" id="g1"><div class="ic"><i></i></div><h4>Membership</h4><p>Affiliate, regular and honorary categories.</p><a class="link">Categories →</a></div>
 <div class="card rv" id="g2"><div class="ic"><i></i></div><h4>Education</h4><p>Accredited CME, workshops and the fellowship.</p><a class="link">Activities →</a></div>
 <div class="card rv" id="g3"><div class="ic"><i></i></div><h4>Committees &amp; regulations</h4><p>The committees, bylaws and forms.</p><a class="link">Documents →</a></div>
</div></div></section>

<section id="numbers"><div class="wrap"><div class="plate rv"><div class="kk">The society in numbers</div><h2 class="title">Measured impact, proven trust</h2><div class="stats">{statshtml}</div></div></div></section>

<section id="board"><div class="wrap"><div class="sechead rv"><div class="kk">Leadership</div><h2 class="title">Board Members</h2></div>
 {chair}
 <div class="members">{mems}</div>
</div></section>

<section id="membership"><div class="wrap"><div class="sechead rv"><div class="kk">Membership</div><h2 class="title">Join the society</h2></div>
 <div class="grid-3">{tiers}</div>
</div></section>

<section id="committees"><div class="wrap"><div class="sechead rv"><div class="kk">Governance</div><h2 class="title">Committees &amp; Regulations</h2></div>
 <div class="grid-3">{coms}</div>
 <div class="sechead rv" style="margin:56px 0 24px"><div class="kk">Documents</div><h2 class="title" style="font-size:30px">Regulations library</h2></div>
 <div class="docwrap">
  <div class="card doclist rv" id="docs">{docs}</div>
  <div class="card docview rv"><div class="dvh"><h4 id="docview-title">SSCRS Basic Bylaw</h4><span class="dvbtn">Open in new tab ↗</span></div><div class="docprev">PDF preview</div></div>
 </div>
</div></section>

<section id="education"><div class="wrap"><div class="sechead rv"><div class="kk">Education &amp; Conferences</div><h2 class="title">Learn with the society</h2></div>
 <div class="band rv"><div><div class="kk">Annual Forum · 15–17 April 2026 · Riyadh</div><h3>SSCRS Annual Forum 2026 — registration is open</h3><p>Three days of keynote lectures, live surgery demonstrations and professional workshops.</p></div><a class="btn btn-o sm" style="background:#fff;border:0;color:var(--ink)">Register</a></div>
 <div style="margin-top:28px">{events}</div>
</div></section>

<section id="faq"><div class="wrap"><div class="sechead rv" style="text-align:center"><div class="kk">Help</div><h2 class="title">Frequently asked</h2></div>
 <div class="faq rv">{faq}</div>
</div></section>

<footer id="footer"><div class="wrap"><div class="cols">
 <div><div class="lock" style="color:#fff;margin-bottom:12px"><img src="assets/seal.png">Saudi Society of<br>Colon &amp; Rectal Surgery</div><p style="font-size:14px;max-width:32ch;opacity:.8">Advancing colorectal surgical excellence across the Kingdom since 2009.</p></div>
 <div><h5>Society</h5><ul><li>About</li><li>Founding Members</li><li>Board</li><li>In Numbers</li></ul></div>
 <div><h5>Membership</h5><ul><li>Affiliate</li><li>Regular</li><li>Honorary</li><li>Directory</li></ul></div>
 <div><h5>Connect</h5><ul><li>info@sscrs.org</li><li>Education</li><li>Committees</li><li>News</li></ul></div>
</div><div class="copy"><span>© 2026 Saudi Society of Colon &amp; Rectal Surgery</span><span>Privacy · Terms</span></div></div></footer>
''')

CFG = '''
window.CFG={
 lightParam:false, vpad:92, hoverSel:'.card,.feature,.t,.ev,.doc', hoverFrom:4.5,
 scroll:[[0,0],[7.0,0],[9.0,'#glance'],[13.0,'#numbers'],[17.0,'#board'],[20.5,'#board'],[23.5,'#membership'],[28.5,'#committees'],[32.5,'#committees'],[35.0,'#docs'],[38.5,'#education'],[42.0,'#education'],[44.5,'#faq'],[52.5,'#faq'],[54.5,'#footer'],[57.0,'#footer']],
 path:[[0,1540,560],[4.2,1540,560],[5.6,'#cta'],[6.6,'#cta'],[8.0,760,520],
  [10.5,'#g0'],[11.6,'#g1'],[12.6,'#g3'],[15.5,760,520],
  [18.5,'#chair'],[21.5,'#mem-1'],[22.6,'#mem-2'],
  [25.5,'#tier-0'],[27.0,'#tier-1'],[28.0,'#tier-1'],
  [31.0,'#com-1'],[32.4,'#com-4'],[34.6,'#doc-0'],[36.2,'#doc-1'],
  [39.5,'#ev-0'],[41.0,'#ev-1'],
  [44.0,760,520],[45.6,'#faq-q0'],[46.2,'#faq-q0'],[49.0,'#faq-q1'],[49.8,'#faq-q1'],[52.0,'#faq-q0'],[54.0,1540,560]],
 clicks:[6.1,27.5,36.2,46.2,49.8],
 docs:[{list:'#docs',title:'#docview-title',titles:['SSCRS Basic Bylaw','Membership Regulations','Financial Regulations','Board Election Rules','Membership Application Form'],start:0,sched:[[36.2,1]]}],
 faq:[{id:'#faq-q0',at:46.2},{id:'#faq-q1',at:49.8}],
 end:{at:57.2,seal:'assets/seal.png',title:'Saudi Society of Colon & Rectal Surgery',sub:'الجمعية السعودية لجراحة القولون والمستقيم',label:'SSCRS'}
};
'''

html=f'''<!doctype html><html lang="en" data-t="A"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>tour15</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&family=IBM+Plex+Sans:wght@400;500;600&family=Noto+Naskh+Arabic:wght@400;700&display=swap" rel="stylesheet">
<style>
{chr(10).join(rootvars(k,v) for k,v in THEME.items())}
{CSS}
</style></head><body>
<header><div class="wrap"><a class="lock"><img src="assets/seal.png"><span>Saudi Society of<br>Colon &amp; Rectal Surgery</span></a>
<nav><a>About</a><a>Board</a><a>Membership</a><a>Committees</a><a>Education</a></nav>
<a class="ar" style="font-size:14px;color:var(--accent)">العربية</a><a class="hcta">Join the society</a></div></header>
{VIEWS}
<script src="data.js"></script>
<script>document.documentElement.dataset.t=(new URLSearchParams(location.search).get('t')||'A');</script>
{'<script>'+CFG+'</script>'}
<script src="engine.js"></script>
</body></html>'''
open(OUT,'w',encoding='utf-8').write(html)
print('tour15.html written',len(html),'bytes')
