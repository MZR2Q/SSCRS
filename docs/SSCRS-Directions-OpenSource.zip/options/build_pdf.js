const { chromium } = require('playwright'); const path=require('path');
(async()=>{const b=await chromium.launch(); const p=await b.newPage();
 await p.goto('file://'+path.join(__dirname,'options.html'),{waitUntil:'networkidle'});
 await p.evaluate(()=>document.fonts.ready); await p.waitForTimeout(600);
 await p.pdf({path:'/home/user/SSCRS/docs/SSCRS-Style-Options.pdf',format:'A4',printBackground:true,preferCSSPageSize:true,margin:{top:0,right:0,bottom:0,left:0}});
 console.log('pdf ok'); await b.close();})();
